<?php
/**
 * BioNixus Theme Functions
 *
 * @package BioNixus
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function bionixus_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('editor-styles');
    
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'bionixus'),
        'footer'  => __('Footer Menu', 'bionixus'),
    ));
    
    add_image_size('article-thumbnail', 800, 450, true);
    add_image_size('featured-image', 1200, 600, true);
}
add_action('after_setup_theme', 'bionixus_setup');

/**
 * Enqueue Scripts and Styles
 */
function bionixus_scripts() {
    wp_enqueue_style('bionixus-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap', array(), null);
    wp_enqueue_style('bionixus-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    wp_enqueue_script('bionixus-main', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'bionixus_scripts');

/**
 * Register Widget Areas
 */
function bionixus_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Column 1', 'bionixus'),
        'id'            => 'footer-1',
        'description'   => __('Footer widget area 1', 'bionixus'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-heading">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 2', 'bionixus'),
        'id'            => 'footer-2',
        'description'   => __('Footer widget area 2', 'bionixus'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-heading">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'bionixus_widgets_init');

/**
 * Custom Post Meta for Blog Posts
 */
function bionixus_add_meta_boxes() {
    add_meta_box(
        'bionixus_post_meta',
        __('Article Details', 'bionixus'),
        'bionixus_post_meta_callback',
        'post',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'bionixus_add_meta_boxes');

function bionixus_post_meta_callback($post) {
    wp_nonce_field('bionixus_post_meta', 'bionixus_post_meta_nonce');
    
    $author_role = get_post_meta($post->ID, '_author_role', true);
    $read_time = get_post_meta($post->ID, '_read_time', true);
    $is_featured = get_post_meta($post->ID, '_is_featured', true);
    
    ?>
    <p>
        <label for="author_role"><?php _e('Author Role:', 'bionixus'); ?></label>
        <input type="text" id="author_role" name="author_role" value="<?php echo esc_attr($author_role); ?>" class="widefat" />
    </p>
    <p>
        <label for="read_time"><?php _e('Read Time:', 'bionixus'); ?></label>
        <input type="text" id="read_time" name="read_time" value="<?php echo esc_attr($read_time); ?>" class="widefat" placeholder="e.g., 5 min read" />
    </p>
    <p>
        <label>
            <input type="checkbox" name="is_featured" value="1" <?php checked($is_featured, '1'); ?> />
            <?php _e('Featured Article', 'bionixus'); ?>
        </label>
    </p>
    <?php
}

function bionixus_save_post_meta($post_id) {
    if (!isset($_POST['bionixus_post_meta_nonce']) || !wp_verify_nonce($_POST['bionixus_post_meta_nonce'], 'bionixus_post_meta')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['author_role'])) {
        update_post_meta($post_id, '_author_role', sanitize_text_field($_POST['author_role']));
    }
    
    if (isset($_POST['read_time'])) {
        update_post_meta($post_id, '_read_time', sanitize_text_field($_POST['read_time']));
    }
    
    update_post_meta($post_id, '_is_featured', isset($_POST['is_featured']) ? '1' : '0');
}
add_action('save_post', 'bionixus_save_post_meta');

/**
 * Helper Functions
 */
function bionixus_get_read_time($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $read_time = get_post_meta($post_id, '_read_time', true);
    
    if (!$read_time) {
        $content = get_post_field('post_content', $post_id);
        $word_count = str_word_count(strip_tags($content));
        $minutes = ceil($word_count / 200);
        $read_time = $minutes . ' min read';
    }
    
    return $read_time;
}

function bionixus_get_author_role($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $role = get_post_meta($post_id, '_author_role', true);
    return $role ? $role : 'Author';
}

function bionixus_is_featured($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    return get_post_meta($post_id, '_is_featured', true) === '1';
}

/**
 * Get Featured Posts
 */
function bionixus_get_featured_posts($limit = 2) {
    return new WP_Query(array(
        'post_type'      => 'post',
        'posts_per_page' => $limit,
        'meta_key'       => '_is_featured',
        'meta_value'     => '1',
    ));
}

/**
 * Customizer Settings
 */
function bionixus_customize_register($wp_customize) {
    $wp_customize->add_section('bionixus_contact', array(
        'title'    => __('Contact Information', 'bionixus'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('bionixus_email', array(
        'default'           => 'admin@bionixus.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('bionixus_email', array(
        'label'   => __('Email Address', 'bionixus'),
        'section' => 'bionixus_contact',
        'type'    => 'email',
    ));
    
    $wp_customize->add_setting('bionixus_phone_uk', array(
        'default'           => '+447727666682',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('bionixus_phone_uk', array(
        'label'   => __('UK Phone Number', 'bionixus'),
        'section' => 'bionixus_contact',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('bionixus_phone_us', array(
        'default'           => '+18884655557',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('bionixus_phone_us', array(
        'label'   => __('US Phone Number', 'bionixus'),
        'section' => 'bionixus_contact',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('bionixus_address_uk', array(
        'default'           => '128 City Road, London, England EC1V 2NX, GB',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('bionixus_address_uk', array(
        'label'   => __('UK Address', 'bionixus'),
        'section' => 'bionixus_contact',
        'type'    => 'textarea',
    ));
    
    $wp_customize->add_setting('bionixus_address_us', array(
        'default'           => '1309 Coffeen Avenue STE 1200 Sheridan, Wyoming 82801, USA',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('bionixus_address_us', array(
        'label'   => __('US Address', 'bionixus'),
        'section' => 'bionixus_contact',
        'type'    => 'textarea',
    ));
    
    $wp_customize->add_section('bionixus_social', array(
        'title'    => __('Social Media', 'bionixus'),
        'priority' => 35,
    ));
    
    $wp_customize->add_setting('bionixus_linkedin', array(
        'default'           => 'https://www.linkedin.com/company/bionixus/',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('bionixus_linkedin', array(
        'label'   => __('LinkedIn URL', 'bionixus'),
        'section' => 'bionixus_social',
        'type'    => 'url',
    ));
    
    $wp_customize->add_setting('bionixus_facebook', array(
        'default'           => 'https://www.facebook.com/Bionixus',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('bionixus_facebook', array(
        'label'   => __('Facebook URL', 'bionixus'),
        'section' => 'bionixus_social',
        'type'    => 'url',
    ));
    
    $wp_customize->add_setting('bionixus_instagram', array(
        'default'           => 'https://www.instagram.com/bionixus_',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('bionixus_instagram', array(
        'label'   => __('Instagram URL', 'bionixus'),
        'section' => 'bionixus_social',
        'type'    => 'url',
    ));
}
add_action('customize_register', 'bionixus_customize_register');

/**
 * Contact Form Handler
 */
function bionixus_handle_contact_form() {
    if (!isset($_POST['bionixus_contact_nonce']) || !wp_verify_nonce($_POST['bionixus_contact_nonce'], 'bionixus_contact_form')) {
        wp_die(__('Security check failed', 'bionixus'));
    }
    
    $name = sanitize_text_field($_POST['contact_name']);
    $email = sanitize_email($_POST['contact_email']);
    $company = sanitize_text_field($_POST['contact_company']);
    $message = sanitize_textarea_field($_POST['contact_message']);
    
    $to = get_theme_mod('bionixus_email', 'admin@bionixus.com');
    $subject = sprintf(__('New Contact Form Submission from %s', 'bionixus'), $name);
    
    $body = "Name: $name\n";
    $body .= "Email: $email\n";
    $body .= "Company: $company\n\n";
    $body .= "Message:\n$message";
    
    $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email);
    
    $sent = wp_mail($to, $subject, $body, $headers);
    
    if ($sent) {
        wp_redirect(add_query_arg('contact', 'success', wp_get_referer()));
    } else {
        wp_redirect(add_query_arg('contact', 'error', wp_get_referer()));
    }
    exit;
}
add_action('admin_post_bionixus_contact', 'bionixus_handle_contact_form');
add_action('admin_post_nopriv_bionixus_contact', 'bionixus_handle_contact_form');
