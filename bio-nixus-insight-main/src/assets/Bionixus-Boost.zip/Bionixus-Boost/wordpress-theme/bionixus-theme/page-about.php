<?php
/**
 * Template Name: About Page
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <!-- Header -->
    <section class="section" style="background: white; border-bottom: 1px solid var(--gray-200);">
        <div class="container">
            <div style="max-width: 700px;">
                <p class="section-label">About BioNixus</p>
                <h1>Our Story</h1>
                <p style="font-size: 1.25rem; color: var(--gray-600);">A leading market research consultancy dedicated to transforming healthcare insights into strategic advantage.</p>
            </div>
        </div>
    </section>

    <!-- Mission Section -->
    <section class="section" style="background: var(--gray-50);">
        <div class="container">
            <div class="about-grid">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=1000&auto=format&fit=crop" alt="BioNixus Mission">
                </div>
                <div class="about-content">
                    <p class="section-label">Our Mission</p>
                    <h2>Empowering Healthcare Decisions Through Data</h2>
                    <p>BioNixus was founded with a clear mission: to bridge the gap between data and strategic action in healthcare markets. We believe that every organization deserves access to rigorous, actionable market intelligence.</p>
                    <p>Our team combines deep pharmaceutical industry experience with methodological excellence, ensuring that every insight we deliver meets the highest standards of quality and relevance.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="section" style="background: white;">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Our Values</p>
                <h2>What Drives Us</h2>
            </div>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                    <h3>Rigor</h3>
                    <p>Unwavering commitment to methodological excellence and data quality in every project we undertake.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
                    </div>
                    <h3>Integrity</h3>
                    <p>Transparent methodologies and honest insights, even when findings challenge assumptions.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
                    </div>
                    <h3>Impact</h3>
                    <p>Focus on delivering insights that drive real business outcomes and strategic advantage.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <h3>Partnership</h3>
                    <p>Collaborative approach that treats every client relationship as a long-term strategic partnership.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Global Presence -->
    <section class="section" style="background: var(--gray-50);">
        <div class="container">
            <div class="about-grid">
                <div class="about-content">
                    <p class="section-label">Global Presence</p>
                    <h2>Strategically Located to Serve You</h2>
                    <p>With offices in London and the United States, BioNixus is positioned to serve clients across time zones while maintaining deep connections to the markets we study.</p>
                    
                    <div style="margin-top: 2rem;">
                        <h4 style="font-size: 1rem; margin-bottom: 0.5rem;">United Kingdom</h4>
                        <p style="color: var(--gray-600); font-size: 0.9375rem;"><?php echo esc_html(get_theme_mod('bionixus_address_uk', '128 City Road, London, England EC1V 2NX, GB')); ?></p>
                        
                        <h4 style="font-size: 1rem; margin-bottom: 0.5rem; margin-top: 1.5rem;">United States</h4>
                        <p style="color: var(--gray-600); font-size: 0.9375rem;"><?php echo esc_html(get_theme_mod('bionixus_address_us', '1309 Coffeen Avenue STE 1200 Sheridan, Wyoming 82801, USA')); ?></p>
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="Global Presence">
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Partner with BioNixus?</h2>
                <p>Let's discuss how our expertise can support your strategic objectives.</p>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-white">Get in Touch</a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
