/**
 * BioNixus Theme JavaScript
 */

(function() {
    'use strict';

    // Header scroll effect
    const header = document.getElementById('site-header');
    
    function handleScroll() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }
    
    window.addEventListener('scroll', handleScroll);
    handleScroll();

    // Mobile menu toggle
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileNav = document.getElementById('mobile-nav');
    
    if (mobileMenuToggle && mobileNav) {
        mobileMenuToggle.addEventListener('click', function() {
            mobileNav.classList.toggle('active');
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Image grayscale hover effect
    document.querySelectorAll('.about-image img, .article-image img').forEach(img => {
        img.addEventListener('mouseenter', function() {
            this.style.filter = 'grayscale(0%)';
        });
        img.addEventListener('mouseleave', function() {
            this.style.filter = 'grayscale(100%) contrast(1.1)';
        });
    });

})();
