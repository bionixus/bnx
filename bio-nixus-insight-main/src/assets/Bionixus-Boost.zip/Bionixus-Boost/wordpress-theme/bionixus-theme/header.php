<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header" id="site-header">
    <div class="container">
        <nav class="nav-container">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    Bio<span>Nixus</span>
                <?php endif; ?>
            </a>
            
            <div class="main-nav">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'items_wrap'     => '%3$s',
                    'fallback_cb'    => 'bionixus_default_menu',
                ));
                ?>
            </div>
            
            <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary nav-cta">
                Contact Us
            </a>
            
            <button class="mobile-menu-toggle" aria-label="Toggle menu" id="mobile-menu-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </nav>
    </div>
    
    <div class="mobile-nav" id="mobile-nav">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'container'      => false,
            'fallback_cb'    => 'bionixus_default_menu',
        ));
        ?>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary" style="margin-top: 1rem; width: 100%;">
            Contact Us
        </a>
    </div>
</header>

<?php
function bionixus_default_menu() {
    ?>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'current' : ''; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/services')); ?>" class="<?php echo is_page('services') ? 'current' : ''; ?>">Services</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>" class="<?php echo is_page('about') ? 'current' : ''; ?>">About</a>
    <a href="<?php echo esc_url(home_url('/insights')); ?>" class="<?php echo is_page('insights') || is_singular('post') ? 'current' : ''; ?>">Insights</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="<?php echo is_page('contact') ? 'current' : ''; ?>">Contact</a>
    <?php
}
?>
