# BioNixus WordPress Theme

A McKinsey-inspired professional WordPress theme for BioNixus Market Research.

## Features

- Deep navy color scheme (#003366, #0066CC)
- Playfair Display serif typography for headings
- Inter sans-serif for body text
- Clean, minimalist professional layouts
- Fully responsive design
- Custom post meta for articles (author role, read time, featured status)
- Customizer settings for contact information and social media
- Built-in contact form functionality

## Installation

1. Download the `bionixus-theme` folder
2. Compress it into a .zip file
3. In WordPress Admin, go to **Appearance > Themes > Add New > Upload Theme**
4. Upload the .zip file and activate

## Page Setup

After activating the theme, create these pages with the specified templates:

1. **Home** - Set as Front Page (uses front-page.php automatically)
2. **Services** - Use template "Services Page"
3. **About** - Use template "About Page"  
4. **Contact** - Use template "Contact Page"
5. **Insights** - Use template "Insights/Blog Page"

### Setting the Front Page

1. Go to **Settings > Reading**
2. Select "A static page"
3. Set "Front page" to your Home page
4. Set "Posts page" to your Insights page

## Menu Setup

1. Go to **Appearance > Menus**
2. Create a new menu called "Primary Menu"
3. Add your pages: Home, Services, About, Insights, Contact
4. Assign to "Primary Menu" location

## Customizer Settings

Go to **Appearance > Customize** to set:

### Contact Information
- Email Address
- UK Phone Number
- US Phone Number
- UK Address
- US Address

### Social Media
- LinkedIn URL
- Facebook URL
- Instagram URL

## Blog Posts

When creating blog posts, you'll see an "Article Details" meta box in the sidebar:

- **Author Role**: e.g., "Research Analyst", "Research Team"
- **Read Time**: e.g., "5 min read"
- **Featured Article**: Check to feature on the Insights page

## Importing Existing Content

Use the WordPress WXR export file to import your existing blog posts:

1. Go to **Tools > Import**
2. Select "WordPress"
3. Upload your export file
4. Map authors as needed

## Theme Structure

```
bionixus-theme/
├── style.css          # Main stylesheet with all design tokens
├── functions.php      # Theme functions and setup
├── header.php         # Site header with navigation
├── footer.php         # Site footer
├── front-page.php     # Home page template
├── page-services.php  # Services page template
├── page-about.php     # About page template
├── page-contact.php   # Contact page template
├── page-insights.php  # Blog listing template
├── single.php         # Single post template
├── index.php          # Fallback template
└── assets/
    └── js/
        └── main.js    # Frontend JavaScript
```

## Support

For support, contact admin@bionixus.com
