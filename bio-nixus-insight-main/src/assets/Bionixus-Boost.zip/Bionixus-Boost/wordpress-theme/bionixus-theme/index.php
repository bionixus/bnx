<?php
/**
 * Index Template (fallback)
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <section class="section">
        <div class="container">
            <div class="insights-grid">
                <?php
                if (have_posts()) :
                    while (have_posts()) : the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="article-card">
                    <div class="article-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('article-thumbnail'); ?>
                        <?php else : ?>
                            <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="<?php the_title_attribute(); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="article-content">
                        <div class="article-meta">
                            <span class="article-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                            <span><?php echo get_the_date('F j, Y'); ?></span>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <p class="article-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <div class="article-footer">
                            <span class="article-author"><?php the_author(); ?></span>
                            <span class="article-readtime"><?php echo bionixus_get_read_time(); ?></span>
                        </div>
                    </div>
                </a>
                <?php
                    endwhile;
                else :
                ?>
                <p>No posts found.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
