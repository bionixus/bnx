<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
                    Bio<span>Nixus</span>
                </a>
                <p>Delivering actionable insights that drive strategic decisions in healthcare and pharmaceutical markets across the Middle East and Africa.</p>
            </div>
            
            <div class="footer-column">
                <h4 class="footer-heading">Services</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url(home_url('/services#quantitative')); ?>">Quantitative Research</a></li>
                    <li><a href="<?php echo esc_url(home_url('/services#qualitative')); ?>">Qualitative Research</a></li>
                    <li><a href="<?php echo esc_url(home_url('/services#analytics')); ?>">Market Analytics</a></li>
                    <li><a href="<?php echo esc_url(home_url('/services#regional')); ?>">Regional Expertise</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h4 class="footer-heading">Company</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url(home_url('/insights')); ?>">Insights</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h4 class="footer-heading">Contact</h4>
                <ul class="footer-links">
                    <li><?php echo esc_html(get_theme_mod('bionixus_address_uk', '128 City Road, London, England EC1V 2NX, GB')); ?></li>
                    <li><a href="mailto:<?php echo esc_attr(get_theme_mod('bionixus_email', 'admin@bionixus.com')); ?>"><?php echo esc_html(get_theme_mod('bionixus_email', 'admin@bionixus.com')); ?></a></li>
                    <li><a href="tel:<?php echo esc_attr(get_theme_mod('bionixus_phone_uk', '+447727666682')); ?>"><?php echo esc_html(get_theme_mod('bionixus_phone_uk', '+447727666682')); ?></a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p class="footer-copyright">
                &copy; <?php echo date('Y'); ?> BioNixus. All rights reserved.
            </p>
            
            <div class="footer-social">
                <?php if (get_theme_mod('bionixus_linkedin')) : ?>
                <a href="<?php echo esc_url(get_theme_mod('bionixus_linkedin')); ?>" target="_blank" rel="noopener" aria-label="LinkedIn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>
                </a>
                <?php endif; ?>
                
                <?php if (get_theme_mod('bionixus_facebook')) : ?>
                <a href="<?php echo esc_url(get_theme_mod('bionixus_facebook')); ?>" target="_blank" rel="noopener" aria-label="Facebook">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                </a>
                <?php endif; ?>
                
                <?php if (get_theme_mod('bionixus_instagram')) : ?>
                <a href="<?php echo esc_url(get_theme_mod('bionixus_instagram')); ?>" target="_blank" rel="noopener" aria-label="Instagram">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
