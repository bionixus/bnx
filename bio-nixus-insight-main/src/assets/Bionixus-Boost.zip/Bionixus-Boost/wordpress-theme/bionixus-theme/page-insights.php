<?php
/**
 * Template Name: Insights/Blog Page
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <!-- Header -->
    <section class="section" style="background: white; border-bottom: 1px solid var(--gray-200);">
        <div class="container">
            <div style="max-width: 700px;">
                <p class="section-label">Insights & Research</p>
                <h1>Insights</h1>
                <p style="font-size: 1.25rem; color: var(--gray-600);">Expert perspectives on healthcare markets, pharmaceutical research, and the latest trends shaping the industry.</p>
            </div>
        </div>
    </section>

    <?php
    $featured_query = bionixus_get_featured_posts(1);
    if ($featured_query->have_posts()) :
        $featured_query->the_post();
    ?>
    <!-- Featured Article -->
    <section class="section-sm" style="background: var(--gray-50);">
        <div class="container">
            <p class="section-label" style="margin-bottom: 2rem;">Featured</p>
            <a href="<?php the_permalink(); ?>" class="article-card" style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; border: none; background: transparent;">
                <div class="article-image" style="height: 400px;">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('featured-image', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                    <?php else : ?>
                        <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="<?php the_title_attribute(); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php endif; ?>
                </div>
                <div>
                    <div class="article-meta" style="margin-bottom: 1rem;">
                        <span class="article-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                        <span><?php echo get_the_date('F j, Y'); ?></span>
                    </div>
                    <h2 style="font-size: 2rem; margin-bottom: 1rem;"><?php the_title(); ?></h2>
                    <p style="font-size: 1.125rem; color: var(--gray-600); margin-bottom: 1.5rem;"><?php echo wp_trim_words(get_the_excerpt(), 30); ?></p>
                    <div class="article-footer" style="border: none; padding: 0;">
                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <div style="width: 40px; height: 40px; background: var(--gray-200); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            </div>
                            <div>
                                <p style="font-size: 0.875rem; font-weight: 500; color: var(--primary-navy); margin: 0;"><?php the_author(); ?></p>
                                <p style="font-size: 0.75rem; color: var(--gray-500); margin: 0;"><?php echo bionixus_get_author_role(); ?></p>
                            </div>
                        </div>
                        <span class="article-readtime"><?php echo bionixus_get_read_time(); ?></span>
                    </div>
                </div>
            </a>
        </div>
    </section>
    <?php
        wp_reset_postdata();
    endif;
    ?>

    <!-- Category Filter -->
    <section style="padding: 2rem 0; background: white; border-bottom: 1px solid var(--gray-200);">
        <div class="container">
            <div style="display: flex; flex-wrap: wrap; gap: 1rem;">
                <a href="<?php echo esc_url(home_url('/insights')); ?>" style="font-size: 0.875rem; font-weight: 500; color: var(--primary-navy); border-bottom: 2px solid var(--primary-blue); padding-bottom: 0.25rem;">All Articles</a>
                <?php
                $categories = get_categories();
                foreach ($categories as $category) :
                ?>
                <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" style="font-size: 0.875rem; color: var(--gray-500); padding-bottom: 0.25rem;"><?php echo esc_html($category->name); ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Articles Grid -->
    <section class="section" style="background: white;">
        <div class="container">
            <div class="insights-grid">
                <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $blog_query = new WP_Query(array(
                    'post_type'      => 'post',
                    'posts_per_page' => 9,
                    'paged'          => $paged,
                ));
                
                if ($blog_query->have_posts()) :
                    while ($blog_query->have_posts()) : $blog_query->the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="article-card">
                    <div class="article-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('article-thumbnail'); ?>
                        <?php else : ?>
                            <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="<?php the_title_attribute(); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="article-content">
                        <div class="article-meta">
                            <span class="article-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                            <span><?php echo get_the_date('F j, Y'); ?></span>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <p class="article-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <div class="article-footer">
                            <span class="article-author"><?php the_author(); ?></span>
                            <span class="article-readtime"><?php echo bionixus_get_read_time(); ?></span>
                        </div>
                    </div>
                </a>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                <p>No articles found.</p>
                <?php endif; ?>
            </div>
            
            <?php if ($blog_query->max_num_pages > 1) : ?>
            <div style="text-align: center; margin-top: 3rem;">
                <?php
                echo paginate_links(array(
                    'total'   => $blog_query->max_num_pages,
                    'current' => $paged,
                ));
                ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Newsletter CTA -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content">
                <h2>Stay informed</h2>
                <p>Subscribe to receive our latest insights, research reports, and industry analysis directly in your inbox.</p>
                <form style="display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center; max-width: 400px; margin: 0 auto;">
                    <input type="email" placeholder="Enter your email" style="flex: 1; min-width: 200px; padding: 0.75rem 1rem; border: none;">
                    <button type="submit" class="btn btn-white">Subscribe</button>
                </form>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
