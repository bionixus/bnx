<?php
/**
 * Single Post Template
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <?php while (have_posts()) : the_post(); ?>
    
    <!-- Post Header -->
    <section class="single-post-header">
        <div class="container">
            <div style="max-width: 800px;">
                <div class="post-meta">
                    <span class="post-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                    <span><?php echo get_the_date('F j, Y'); ?></span>
                    <span><?php echo bionixus_get_read_time(); ?></span>
                </div>
                <h1><?php the_title(); ?></h1>
                <p style="font-size: 1.25rem; color: var(--gray-600); margin-top: 1.5rem;">
                    <?php echo get_the_excerpt(); ?>
                </p>
                <div style="display: flex; align-items: center; gap: 1rem; margin-top: 2rem;">
                    <div style="width: 48px; height: 48px; background: var(--gray-200); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </div>
                    <div>
                        <p style="font-weight: 600; color: var(--primary-navy); margin: 0;"><?php the_author(); ?></p>
                        <p style="font-size: 0.875rem; color: var(--gray-500); margin: 0;"><?php echo bionixus_get_author_role(); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Image -->
    <?php if (has_post_thumbnail()) : ?>
    <section style="background: var(--gray-50); padding: 3rem 0;">
        <div class="container">
            <div style="max-width: 1000px; margin: 0 auto;">
                <?php the_post_thumbnail('full', array('style' => 'width: 100%; height: auto; filter: grayscale(100%) contrast(1.1);')); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Post Content -->
    <section class="single-post-content">
        <div class="container">
            <div class="post-content">
                <?php the_content(); ?>
                
                <!-- Author Box -->
                <div class="post-author-box">
                    <div class="author-avatar">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </div>
                    <div>
                        <p class="author-name"><?php the_author(); ?></p>
                        <p class="author-role"><?php echo bionixus_get_author_role(); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php endwhile; ?>

    <!-- Related Posts -->
    <section class="section" style="background: var(--gray-50);">
        <div class="container">
            <h2 style="margin-bottom: 2rem;">Related Articles</h2>
            <div class="insights-grid">
                <?php
                $related = new WP_Query(array(
                    'posts_per_page' => 3,
                    'post__not_in'   => array(get_the_ID()),
                    'category__in'   => wp_get_post_categories(get_the_ID()),
                ));
                
                if ($related->have_posts()) :
                    while ($related->have_posts()) : $related->the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="article-card">
                    <div class="article-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('article-thumbnail'); ?>
                        <?php else : ?>
                            <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="<?php the_title_attribute(); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="article-content">
                        <div class="article-meta">
                            <span class="article-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                            <span><?php echo get_the_date('F j, Y'); ?></span>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <p class="article-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <div class="article-footer">
                            <span class="article-author"><?php the_author(); ?></span>
                            <span class="article-readtime"><?php echo bionixus_get_read_time(); ?></span>
                        </div>
                    </div>
                </a>
                <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Transform Your Market Strategy?</h2>
                <p>Partner with BioNixus to gain the insights you need to succeed in healthcare markets.</p>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-white">Schedule a Consultation</a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
