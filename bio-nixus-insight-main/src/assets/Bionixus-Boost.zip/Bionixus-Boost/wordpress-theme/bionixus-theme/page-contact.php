<?php
/**
 * Template Name: Contact Page
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <!-- Header -->
    <section class="section" style="background: white; border-bottom: 1px solid var(--gray-200);">
        <div class="container">
            <div style="max-width: 700px;">
                <p class="section-label">Contact Us</p>
                <h1>Get in Touch</h1>
                <p style="font-size: 1.25rem; color: var(--gray-600);">Ready to discuss your market research needs? Our team is here to help you make informed strategic decisions.</p>
            </div>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section class="section" style="background: var(--gray-50);">
        <div class="container">
            <div class="contact-grid">
                <div class="contact-form">
                    <h3 style="margin-bottom: 1.5rem;">Send us a message</h3>
                    
                    <?php if (isset($_GET['contact']) && $_GET['contact'] === 'success') : ?>
                    <div style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 1rem; margin-bottom: 1.5rem;">
                        Thank you for your message. We'll be in touch shortly.
                    </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['contact']) && $_GET['contact'] === 'error') : ?>
                    <div style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 1rem; margin-bottom: 1.5rem;">
                        There was an error sending your message. Please try again.
                    </div>
                    <?php endif; ?>
                    
                    <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                        <input type="hidden" name="action" value="bionixus_contact">
                        <?php wp_nonce_field('bionixus_contact_form', 'bionixus_contact_nonce'); ?>
                        
                        <div class="form-group">
                            <label class="form-label" for="contact_name">Full Name *</label>
                            <input type="text" id="contact_name" name="contact_name" class="form-input" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="contact_email">Email Address *</label>
                            <input type="email" id="contact_email" name="contact_email" class="form-input" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="contact_company">Company</label>
                            <input type="text" id="contact_company" name="contact_company" class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="contact_message">Message *</label>
                            <textarea id="contact_message" name="contact_message" class="form-textarea" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%;">Send Message</button>
                    </form>
                </div>
                
                <div class="contact-info">
                    <h3>Contact Information</h3>
                    <ul class="contact-details">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                            <span>
                                <strong>Email</strong><br>
                                <a href="mailto:<?php echo esc_attr(get_theme_mod('bionixus_email', 'admin@bionixus.com')); ?>"><?php echo esc_html(get_theme_mod('bionixus_email', 'admin@bionixus.com')); ?></a>
                            </span>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                            <span>
                                <strong>Phone (UK)</strong><br>
                                <a href="tel:<?php echo esc_attr(get_theme_mod('bionixus_phone_uk', '+447727666682')); ?>"><?php echo esc_html(get_theme_mod('bionixus_phone_uk', '+447727666682')); ?></a>
                            </span>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                            <span>
                                <strong>Phone (US)</strong><br>
                                <a href="tel:<?php echo esc_attr(get_theme_mod('bionixus_phone_us', '+18884655557')); ?>"><?php echo esc_html(get_theme_mod('bionixus_phone_us', '+18884655557')); ?></a>
                            </span>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                            <span>
                                <strong>London Office</strong><br>
                                <?php echo esc_html(get_theme_mod('bionixus_address_uk', '128 City Road, London, England EC1V 2NX, GB')); ?>
                            </span>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                            <span>
                                <strong>US Office</strong><br>
                                <?php echo esc_html(get_theme_mod('bionixus_address_us', '1309 Coffeen Avenue STE 1200 Sheridan, Wyoming 82801, USA')); ?>
                            </span>
                        </li>
                    </ul>
                    
                    <div style="margin-top: 2rem;">
                        <h4 style="font-size: 1rem; margin-bottom: 1rem;">Business Hours</h4>
                        <p style="font-size: 0.9375rem; color: var(--gray-600);">Monday - Friday: 9:00 AM - 6:00 PM<br>Saturday - Sunday: Closed</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
