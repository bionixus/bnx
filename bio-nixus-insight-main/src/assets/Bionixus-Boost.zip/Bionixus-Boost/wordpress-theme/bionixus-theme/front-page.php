<?php
/**
 * Home Page Template
 *
 * @package BioNixus
 */

get_header();
?>

<main>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <span class="hero-label">Healthcare Market Research Excellence</span>
                <h1>Insights that Transform Healthcare Markets</h1>
                <p class="hero-description">
                    BioNixus delivers rigorous, data-driven market research that empowers pharmaceutical and healthcare organizations to make confident strategic decisions across the Middle East and Africa.
                </p>
                <div class="hero-buttons">
                    <a href="<?php echo esc_url(home_url('/services')); ?>" class="btn btn-white">Our Expertise</a>
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline" style="border-color: rgba(255,255,255,0.3); color: white;">Schedule a Consultation</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats section-sm">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number">15+</div>
                    <div class="stat-label">Years Experience</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">200+</div>
                    <div class="stat-label">Projects Delivered</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">25+</div>
                    <div class="stat-label">Countries Covered</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">50+</div>
                    <div class="stat-label">Pharma Clients</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services section">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Our Services</p>
                <h2>Comprehensive Research Solutions</h2>
                <p>We combine methodological rigor with deep regional expertise to deliver insights that matter.</p>
            </div>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                    </div>
                    <h3>Quantitative Research</h3>
                    <p>Large-scale surveys and statistical analysis providing robust, generalizable market insights.</p>
                    <a href="<?php echo esc_url(home_url('/services#quantitative')); ?>" class="service-link">
                        Learn more <span>&rarr;</span>
                    </a>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <h3>Qualitative Research</h3>
                    <p>In-depth interviews and focus groups that reveal the motivations behind healthcare decisions.</p>
                    <a href="<?php echo esc_url(home_url('/services#qualitative')); ?>" class="service-link">
                        Learn more <span>&rarr;</span>
                    </a>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
                    </div>
                    <h3>Market Analytics</h3>
                    <p>Advanced data analytics and competitive intelligence for strategic market positioning.</p>
                    <a href="<?php echo esc_url(home_url('/services#analytics')); ?>" class="service-link">
                        Learn more <span>&rarr;</span>
                    </a>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <h3>Regional Expertise</h3>
                    <p>Unparalleled knowledge of MEA healthcare markets, regulations, and stakeholder landscapes.</p>
                    <a href="<?php echo esc_url(home_url('/services#regional')); ?>" class="service-link">
                        Learn more <span>&rarr;</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about section" style="background: white;">
        <div class="container">
            <div class="about-grid">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1000&auto=format&fit=crop" alt="BioNixus Team">
                </div>
                <div class="about-content">
                    <p class="section-label">About BioNixus</p>
                    <h2>Your Strategic Partner in Healthcare Intelligence</h2>
                    <p>For over a decade, BioNixus has been at the forefront of healthcare market research in the Middle East and Africa. We combine global best practices with deep local expertise to deliver insights that drive results.</p>
                    <ul class="features-list">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Rigorous methodology meeting international standards
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Deep understanding of regional healthcare dynamics
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Actionable insights that inform strategic decisions
                        </li>
                    </ul>
                    <a href="<?php echo esc_url(home_url('/about')); ?>" class="btn btn-primary">Learn More About Us</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Insights Section -->
    <section class="insights section">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Latest Insights</p>
                <h2>Research & Analysis</h2>
                <p>Expert perspectives on healthcare markets and pharmaceutical industry trends.</p>
            </div>
            
            <div class="insights-grid">
                <?php
                $recent_posts = new WP_Query(array(
                    'posts_per_page' => 3,
                    'post_type'      => 'post',
                ));
                
                if ($recent_posts->have_posts()) :
                    while ($recent_posts->have_posts()) : $recent_posts->the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="article-card">
                    <div class="article-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('article-thumbnail'); ?>
                        <?php else : ?>
                            <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop" alt="<?php the_title_attribute(); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="article-content">
                        <div class="article-meta">
                            <span class="article-category"><?php echo get_the_category()[0]->name ?? 'Insights'; ?></span>
                            <span><?php echo get_the_date('F j, Y'); ?></span>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <p class="article-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <div class="article-footer">
                            <span class="article-author"><?php the_author(); ?></span>
                            <span class="article-readtime"><?php echo bionixus_get_read_time(); ?></span>
                        </div>
                    </div>
                </a>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                <p>No articles found.</p>
                <?php endif; ?>
            </div>
            
            <div style="text-align: center; margin-top: 3rem;">
                <a href="<?php echo esc_url(home_url('/insights')); ?>" class="btn btn-outline">View All Insights</a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Transform Your Market Strategy?</h2>
                <p>Partner with BioNixus to gain the insights you need to succeed in healthcare markets.</p>
                <div class="cta-buttons">
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-white">Schedule a Consultation</a>
                    <a href="<?php echo esc_url(home_url('/services')); ?>" class="btn btn-outline" style="border-color: rgba(255,255,255,0.3); color: white;">Explore Our Services</a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
