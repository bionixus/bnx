<?php
/**
 * Template Name: Services Page
 *
 * @package BioNixus
 */

get_header();
?>

<main style="padding-top: 80px;">
    <!-- Header -->
    <section class="section" style="background: white; border-bottom: 1px solid var(--gray-200);">
        <div class="container">
            <div style="max-width: 700px;">
                <p class="section-label">Our Services</p>
                <h1>Research Capabilities</h1>
                <p style="font-size: 1.25rem; color: var(--gray-600);">Comprehensive market research solutions designed to deliver actionable insights for healthcare and pharmaceutical organizations.</p>
            </div>
        </div>
    </section>

    <!-- Quantitative Research -->
    <section class="section" id="quantitative" style="background: var(--gray-50);">
        <div class="container">
            <div class="about-grid">
                <div class="about-content">
                    <p class="section-label">Data-Driven Insights</p>
                    <h2>Quantitative Research</h2>
                    <p>Our quantitative research services provide statistically robust data that enables confident decision-making. We design and execute large-scale studies that deliver reliable, generalizable insights across healthcare markets.</p>
                    <ul class="features-list">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Brand tracking and awareness studies
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Treatment pattern and prescribing behavior analysis
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Patient journey mapping and segmentation
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Pricing and market access research
                        </li>
                    </ul>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000&auto=format&fit=crop" alt="Quantitative Research">
                </div>
            </div>
        </div>
    </section>

    <!-- Qualitative Research -->
    <section class="section" id="qualitative" style="background: white;">
        <div class="container">
            <div class="about-grid">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1000&auto=format&fit=crop" alt="Qualitative Research">
                </div>
                <div class="about-content">
                    <p class="section-label">Deep Understanding</p>
                    <h2>Qualitative Market Research</h2>
                    <p>Our qualitative research uncovers the "why" behind healthcare decisions. Through carefully designed interviews and focus groups, we reveal the motivations, perceptions, and unmet needs that drive stakeholder behavior.</p>
                    <ul class="features-list">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            In-depth physician and KOL interviews
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Focus groups with healthcare professionals
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Patient experience and ethnographic research
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Message testing and concept evaluation
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Market Analytics -->
    <section class="section" id="analytics" style="background: var(--gray-50);">
        <div class="container">
            <div class="about-grid">
                <div class="about-content">
                    <p class="section-label">Strategic Intelligence</p>
                    <h2>Market Analytics</h2>
                    <p>Transform raw data into strategic advantage. Our analytics services combine advanced methodologies with industry expertise to deliver insights that inform competitive positioning and market strategy.</p>
                    <ul class="features-list">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Competitive landscape analysis
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Market sizing and forecasting
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Secondary data analysis and synthesis
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Launch readiness assessments
                        </li>
                    </ul>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop" alt="Market Analytics">
                </div>
            </div>
        </div>
    </section>

    <!-- Regional Expertise -->
    <section class="section" id="regional" style="background: white;">
        <div class="container">
            <div class="about-grid">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=1000&auto=format&fit=crop" alt="Regional Expertise">
                </div>
                <div class="about-content">
                    <p class="section-label">Local Knowledge, Global Standards</p>
                    <h2>Regional Expertise</h2>
                    <p>Deep expertise in healthcare markets across the Middle East and Africa. Our regional specialists bring unparalleled understanding of local regulations, stakeholder landscapes, and market dynamics.</p>
                    <ul class="features-list">
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Gulf Cooperation Council (GCC) markets
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            North African healthcare landscape
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Sub-Saharan Africa market access
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            Regulatory and policy analysis
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content">
                <h2>Let's Discuss Your Research Needs</h2>
                <p>Our team is ready to design a research approach tailored to your specific objectives.</p>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-white">Schedule a Consultation</a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
