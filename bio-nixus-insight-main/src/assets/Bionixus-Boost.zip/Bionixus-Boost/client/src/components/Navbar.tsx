import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Services", href: "/services" },
    { name: "Insights", href: "/insights" },
    { name: "About", href: "/about" },
    { name: "Contact", href: "/contact" },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-white border-b border-border py-4"
          : "bg-transparent py-6"
      )}
      data-testid="navbar"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link href="/" className="cursor-pointer" data-testid="link-logo">
            <span className="font-display text-2xl font-semibold tracking-tight text-[#003366]">
              BioNixus
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                data-testid={`link-nav-${link.name.toLowerCase()}`}
                className={cn(
                  "text-sm font-medium transition-colors relative pb-1",
                  isActive(link.href)
                    ? "text-[#003366] after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-[#0066CC]"
                    : scrolled ? "text-gray-700 hover:text-[#003366]" : "text-gray-700 hover:text-[#003366]"
                )}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="hidden md:block">
            <Link href="/contact">
              <Button 
                size="sm" 
                className="bg-[#003366] hover:bg-[#002244] text-white font-medium px-6"
                data-testid="button-nav-contact"
              >
                Contact Us
              </Button>
            </Link>
          </div>

          <button
            className="md:hidden p-2 text-gray-700"
            onClick={() => setIsOpen(!isOpen)}
            data-testid="button-mobile-menu"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-border shadow-lg">
          <div className="flex flex-col p-6 gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                data-testid={`link-mobile-${link.name.toLowerCase()}`}
                className={cn(
                  "px-4 py-3 text-sm font-medium transition-colors",
                  isActive(link.href)
                    ? "text-[#003366] bg-gray-50"
                    : "text-gray-700 hover:text-[#003366] hover:bg-gray-50"
                )}
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-4 mt-2 border-t border-border">
              <Link href="/contact" onClick={() => setIsOpen(false)}>
                <Button className="w-full bg-[#003366] hover:bg-[#002244]" data-testid="button-mobile-contact">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
