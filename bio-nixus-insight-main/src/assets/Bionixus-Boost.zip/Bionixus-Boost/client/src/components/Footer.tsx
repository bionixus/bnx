import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-[#003366] text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <span className="font-display text-2xl font-semibold tracking-tight">
              BioNixus
            </span>
            <p className="mt-4 text-sm text-blue-200 leading-relaxed max-w-xs">
              Global professional services company specializing in Pharmaceutical Market Research and Operations consultancy.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-6 text-white">Services</h4>
            <ul className="space-y-3 text-sm text-blue-200">
              <li><Link href="/services" className="hover:text-white transition-colors" data-testid="link-footer-research">Market Research</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors" data-testid="link-footer-analytics">Data Analytics</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors" data-testid="link-footer-digital">Digital Transformation</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors" data-testid="link-footer-qualitative">Qualitative Research</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-6 text-white">Company</h4>
            <ul className="space-y-3 text-sm text-blue-200">
              <li><Link href="/about" className="hover:text-white transition-colors" data-testid="link-footer-about">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-white transition-colors" data-testid="link-footer-contact">Contact</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-6 text-white">Contact</h4>
            <ul className="space-y-3 text-sm text-blue-200">
              <li>128 City Road, London, UK</li>
              <li>1309 Coffeen Avenue, Wyoming, USA</li>
              <li className="pt-2">+44 7727 666682</li>
              <li>admin@bionixus.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 py-8">
          <p className="text-sm text-blue-300 text-center">
            © {new Date().getFullYear()} BioNixus Market Research. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
