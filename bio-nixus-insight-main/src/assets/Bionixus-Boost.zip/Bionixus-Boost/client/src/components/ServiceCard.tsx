import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { LucideIcon } from "lucide-react";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href?: string;
}

export function ServiceCard({ icon: Icon, title, description, href = "/services" }: ServiceCardProps) {
  return (
    <Link href={href} className="group block" data-testid={`card-service-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="bg-white border border-gray-200 p-8 h-full transition-all duration-300 hover:border-[#0066CC] hover:shadow-md relative">
        <div className="absolute top-0 left-0 w-1 h-0 bg-[#0066CC] group-hover:h-full transition-all duration-300" />
        
        <Icon className="h-8 w-8 text-[#003366] mb-6" />
        
        <h3 className="font-display text-xl font-semibold mb-3 text-[#003366]">
          {title}
        </h3>
        
        <p className="text-gray-600 mb-6 leading-relaxed text-sm">
          {description}
        </p>
        
        <div className="flex items-center text-[#0066CC] font-medium text-sm">
          <span>Learn more</span>
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}
