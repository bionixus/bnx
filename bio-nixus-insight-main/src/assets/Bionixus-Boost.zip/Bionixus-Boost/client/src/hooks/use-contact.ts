import { useMutation } from "@tanstack/react-query";
import { api, type InsertContactSubmission } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSubmitContact() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: InsertContactSubmission) => {
      // Validate with Zod schema from shared routes before sending
      const validated = api.contact.submit.input.parse(data);
      
      const res = await fetch(api.contact.submit.path, {
        method: api.contact.submit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
           const errorData = await res.json();
           // Try to parse as validation error
           try {
             const error = api.contact.submit.responses[400].parse(errorData);
             throw new Error(error.message);
           } catch {
             throw new Error("Invalid form data");
           }
        }
        throw new Error("Failed to submit contact form. Please try again.");
      }

      return api.contact.submit.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for contacting BioNixus. We will get back to you shortly.",
        variant: "default", 
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
