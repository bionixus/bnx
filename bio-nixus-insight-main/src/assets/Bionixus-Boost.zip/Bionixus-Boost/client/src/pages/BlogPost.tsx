import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Link, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { BlogPost as BlogPostType } from "@shared/schema";
import { ArrowLeft, Calendar, Clock, User, Share2, Linkedin, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

function formatDate(date: Date | string | null) {
  if (!date) return "";
  const d = new Date(date);
  return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

export default function BlogPost() {
  const params = useParams<{ slug: string }>();
  
  const { data: post, isLoading, error } = useQuery<BlogPostType>({
    queryKey: ['/api/blog', params.slug],
    queryFn: async () => {
      const res = await fetch(buildUrl(api.blog.get.path, { slug: params.slug }));
      if (!res.ok) {
        throw new Error("Post not found");
      }
      return res.json();
    },
    enabled: !!params.slug,
  });

  const { data: relatedPosts } = useQuery<BlogPostType[]>({
    queryKey: [api.blog.list.path],
  });

  const otherPosts = relatedPosts?.filter(p => p.slug !== params.slug).slice(0, 3) || [];

  if (error) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow pt-32 pb-20">
          <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
            <h1 className="font-display text-4xl font-semibold text-[#003366] mb-4">Article Not Found</h1>
            <p className="text-gray-600 mb-8">The article you're looking for doesn't exist or has been moved.</p>
            <Link href="/insights">
              <Button variant="outline" className="border-[#003366] text-[#003366]">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Insights
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Hero */}
        <section className="py-16 bg-white border-b border-gray-200" data-testid="section-post-hero">
          <div className="max-w-4xl mx-auto px-6 lg:px-8">
            <Link href="/insights" className="inline-flex items-center text-sm text-gray-500 hover:text-[#003366] mb-8" data-testid="link-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Insights
            </Link>
            
            {isLoading ? (
              <>
                <Skeleton className="h-6 w-32 mb-4" />
                <Skeleton className="h-12 w-full mb-2" />
                <Skeleton className="h-12 w-3/4 mb-6" />
                <Skeleton className="h-6 w-full mb-8" />
              </>
            ) : (
              <>
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                  <span className="text-[#0066CC] font-medium uppercase tracking-wider text-xs">{post?.category}</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" />
                    {formatDate(post?.publishedAt || null)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {post?.readTime}
                  </span>
                </div>
                
                <h1 className="font-display text-4xl md:text-5xl font-semibold text-[#003366] mb-6 leading-tight" data-testid="text-post-title">
                  {post?.title}
                </h1>
                
                <p className="text-xl text-gray-600 leading-relaxed mb-8" data-testid="text-post-excerpt">
                  {post?.excerpt}
                </p>
                
                <div className="flex items-center justify-between pt-8 border-t border-gray-200">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                      <User className="h-6 w-6 text-gray-500" />
                    </div>
                    <div>
                      <p className="font-medium text-[#003366]" data-testid="text-author">{post?.author}</p>
                      <p className="text-sm text-gray-500">{post?.authorRole}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button className="p-2 text-gray-400 hover:text-[#003366] transition-colors" data-testid="button-share">
                      <Share2 className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-[#0077B5] transition-colors" data-testid="button-linkedin">
                      <Linkedin className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-[#1DA1F2] transition-colors" data-testid="button-twitter">
                      <Twitter className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </section>

        {/* Featured Image */}
        {!isLoading && post?.imageUrl && (
          <section className="bg-gray-50">
            <div className="max-w-6xl mx-auto">
              <div className="relative">
                <img 
                  src={post.imageUrl} 
                  alt={post.title}
                  className="w-full h-[400px] md:h-[500px] object-cover grayscale contrast-110"
                  data-testid="img-post-hero"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
              </div>
            </div>
          </section>
        )}

        {/* Article Content */}
        <section className="py-16 bg-white" data-testid="section-post-content">
          <div className="max-w-3xl mx-auto px-6 lg:px-8">
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-6 w-full mt-8" />
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-2/3" />
              </div>
            ) : (
              <article 
                className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-[#003366] prose-p:text-gray-700 prose-a:text-[#0066CC] prose-a:no-underline hover:prose-a:underline"
                dangerouslySetInnerHTML={{ __html: post?.content || "" }}
                data-testid="article-content"
              />
            )}
          </div>
        </section>

        {/* Author Bio */}
        {!isLoading && post && (
          <section className="py-12 bg-gray-50 border-t border-gray-200" data-testid="section-author">
            <div className="max-w-3xl mx-auto px-6 lg:px-8">
              <div className="flex items-start gap-6">
                <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                  <User className="h-8 w-8 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">About the Author</p>
                  <p className="font-display text-xl font-semibold text-[#003366] mb-1">{post.author}</p>
                  <p className="text-sm text-gray-600 mb-3">{post.authorRole}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Expert contributor at BioNixus with extensive experience in healthcare market research and pharmaceutical consulting across the Middle East and Africa regions.
                  </p>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Related Articles */}
        {otherPosts.length > 0 && (
          <section className="py-16 bg-white border-t border-gray-200" data-testid="section-related">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <h2 className="font-display text-2xl font-semibold text-[#003366] mb-8">
                Related Insights
              </h2>
              <div className="grid md:grid-cols-3 gap-8">
                {otherPosts.map((related) => (
                  <Link 
                    key={related.id} 
                    href={`/insights/${related.slug}`} 
                    className="group block"
                    data-testid={`related-article-${related.slug}`}
                  >
                    <div className="bg-white border border-gray-200 h-full transition-all duration-300 hover:border-[#0066CC]">
                      <div className="relative overflow-hidden">
                        <img 
                          src={related.imageUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop"} 
                          alt={related.title}
                          className="w-full h-[180px] object-cover grayscale contrast-110 group-hover:grayscale-0 transition-all duration-500"
                        />
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
                      </div>
                      <div className="p-5">
                        <span className="text-[#0066CC] font-medium uppercase tracking-wider text-xs">{related.category}</span>
                        <h3 className="font-display text-lg font-semibold text-[#003366] mt-2 leading-snug group-hover:text-[#0066CC] transition-colors line-clamp-2">
                          {related.title}
                        </h3>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
}
