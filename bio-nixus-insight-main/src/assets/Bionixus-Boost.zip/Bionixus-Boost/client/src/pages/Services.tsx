import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, CheckCircle2 } from "lucide-react";

export default function Services() {
  const serviceCategories = [
    {
      title: "Quantitative Market Research",
      description: "Deep-dive data collection and analysis to understand market dynamics in the pharmaceutical and healthcare sectors.",
      features: [
        "HCP (Healthcare Professional) interviews",
        "Hospital-level data collection",
        "Area and brick-level data analysis",
        "Large-scale patient satisfaction surveys"
      ],
      image: "https://images.unsplash.com/photo-1579165466741-7f35a4755657?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Qualitative Market Research",
      description: "In-depth exploratory research to uncover the motivations, attitudes, and behaviors driving healthcare decisions.",
      features: [
        "In-depth HCP interviews",
        "Focus groups and advisory boards",
        "Ethnographic patient studies",
        "Key opinion leader research"
      ],
      image: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Market Analytics & Insights",
      description: "Transform raw data into strategic intelligence for informed decision making and competitive advantage.",
      features: [
        "Drug launch forecasting",
        "Competitive landscape assessment",
        "Market entry strategies",
        "Consumer behavior analysis"
      ],
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Header */}
        <section className="py-20 bg-white border-b border-gray-200" data-testid="section-services-header">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                Our Capabilities
              </p>
              <h1 className="font-display text-4xl md:text-5xl font-semibold text-[#003366] mb-6" data-testid="text-services-title">
                Services
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed" data-testid="text-services-description">
                We offer a comprehensive suite of research and consultancy services tailored for the pharmaceutical and healthcare sectors.
              </p>
            </div>
          </div>
        </section>

        {/* Services List */}
        <section className="py-20 bg-white" data-testid="section-services-list">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="space-y-24">
              {serviceCategories.map((service, index) => (
                <div 
                  key={index} 
                  className={`grid lg:grid-cols-2 gap-16 items-center ${index % 2 === 1 ? 'lg:grid-flow-dense' : ''}`}
                  data-testid={`service-item-${index}`}
                >
                  <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                    <div className="relative">
                      <img 
                        src={service.image} 
                        alt={service.title} 
                        className="w-full h-[400px] object-cover grayscale contrast-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/10 to-transparent" />
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
                    </div>
                  </div>
                  
                  <div className={index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                    <h2 className="font-display text-3xl font-semibold text-[#003366] mb-4">
                      {service.title}
                    </h2>
                    <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                      {service.description}
                    </p>
                    
                    <ul className="space-y-4 mb-8">
                      {service.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <CheckCircle2 className="h-5 w-5 text-[#0066CC] mt-0.5 shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Link href="/contact">
                      <Button 
                        variant="outline" 
                        className="border-[#003366] text-[#003366] hover:bg-gray-50 font-medium"
                        data-testid={`button-service-contact-${index}`}
                      >
                        Consult an Expert
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gray-50 border-t border-gray-200" data-testid="section-services-cta">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="font-display text-3xl font-semibold text-[#003366] mb-6">
              Need a custom solution?
            </h2>
            <p className="text-lg text-gray-600 mb-10">
              Every project is tailored to your unique requirements. Let's discuss how we can help.
            </p>
            <Link href="/contact">
              <Button 
                size="lg" 
                className="bg-[#003366] hover:bg-[#002244] text-white px-10 py-6 font-medium"
                data-testid="button-services-cta"
              >
                Get in Touch
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
