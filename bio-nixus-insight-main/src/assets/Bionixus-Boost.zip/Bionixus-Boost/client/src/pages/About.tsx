import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Globe2, HeartHandshake, ShieldCheck, Building2 } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow pt-24">
        {/* Header */}
        <section className="py-20 bg-white border-b border-gray-200" data-testid="section-about-header">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                  About Us
                </p>
                <h1 className="font-display text-4xl md:text-5xl font-semibold text-[#003366] mb-6" data-testid="text-about-title">
                  BioNixus
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed mb-6" data-testid="text-about-description">
                  A global professional services company specializing in Pharmaceutical Market Research, AI Marketing, and Operations consultancy.
                </p>
                <p className="text-gray-600 leading-relaxed">
                  Headquartered in the UK with a strong strategic focus on the Middle East and Africa regions, we position ourselves as the premier partner for pharmaceutical companies seeking to navigate complex healthcare markets successfully.
                </p>
              </div>
              <div className="relative hidden lg:block">
                <img 
                  src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1000&auto=format&fit=crop" 
                  alt="Global Network"
                  className="w-full h-[400px] object-cover grayscale contrast-110"
                  data-testid="img-about-hero"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/10 to-transparent" />
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
              </div>
            </div>
          </div>
        </section>

        {/* Mission */}
        <section className="py-24 bg-gray-50" data-testid="section-about-mission">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                Our Philosophy
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-[#003366] mb-6">
                Driven by Values
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                Our approach combines traditional market research rigor with cutting-edge AI and digital tools. We are passionately curious experts who not only provide the most precise information but shape it to provide a true understanding of society, markets, and people.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { 
                  icon: Globe2, 
                  title: "Regional Expertise", 
                  text: "Deep understanding of Middle East cultural nuances and regulatory landscapes." 
                },
                { 
                  icon: ShieldCheck, 
                  title: "High Standards", 
                  text: "We take data seriously. We adhere to rigorous ethical standards and compliance protocols." 
                },
                { 
                  icon: HeartHandshake, 
                  title: "Client-Centric", 
                  text: "Tailored research solutions designed for your unique needs, not the other way around." 
                },
                { 
                  icon: Building2, 
                  title: "Industry Focus", 
                  text: "Specialized exclusively in pharmaceutical and healthcare sectors for maximum relevance." 
                }
              ].map((item, i) => (
                <div key={i} className="bg-white border border-gray-200 p-8" data-testid={`about-value-${i}`}>
                  <item.icon className="h-8 w-8 text-[#003366] mb-6" />
                  <h3 className="font-display text-xl font-semibold text-[#003366] mb-3">{item.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Global Presence */}
        <section className="py-24 bg-white" data-testid="section-about-presence">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                  Global Presence
                </p>
                <h2 className="font-display text-3xl md:text-4xl font-semibold text-[#003366] mb-6">
                  Offices worldwide
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed mb-8">
                  With headquarters in the United Kingdom and offices in the United States, we serve clients across the globe with a particular focus on the Middle East and Africa regions.
                </p>

                <div className="space-y-6">
                  <div className="border-l-2 border-[#0066CC] pl-6">
                    <h4 className="font-semibold text-[#003366] mb-1">United Kingdom</h4>
                    <p className="text-gray-600 text-sm">128 City Road, London, EC1V 2NX</p>
                  </div>
                  <div className="border-l-2 border-[#0066CC] pl-6">
                    <h4 className="font-semibold text-[#003366] mb-1">United States</h4>
                    <p className="text-gray-600 text-sm">1309 Coffeen Avenue STE 1200, Sheridan, Wyoming 82801</p>
                  </div>
                </div>
              </div>

              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000&auto=format&fit=crop" 
                  alt="Modern Office"
                  className="w-full h-[400px] object-cover grayscale contrast-110"
                  data-testid="img-about-office"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/10 to-transparent" />
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-[#003366]" data-testid="section-about-cta">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-white mb-6">
              Ready to work together?
            </h2>
            <p className="text-lg text-blue-200 mb-10 max-w-2xl mx-auto">
              Let's discuss how BioNixus can help you navigate your market challenges.
            </p>
            <Link href="/contact">
              <Button 
                size="lg" 
                className="bg-white text-[#003366] hover:bg-gray-100 px-10 py-6 font-medium"
                data-testid="button-about-cta"
              >
                Get in Touch
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
