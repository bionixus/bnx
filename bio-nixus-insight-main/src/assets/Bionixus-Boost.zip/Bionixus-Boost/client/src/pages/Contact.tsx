import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema, type InsertContactSubmission } from "@shared/schema";
import { useSubmitContact } from "@/hooks/use-contact";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { z } from "zod";

const formSchema = insertContactSchema.extend({
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
});

export default function Contact() {
  const submitContact = useSubmitContact();
  
  const form = useForm<InsertContactSubmission>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      preferredContact: "Email",
      serviceNeeded: "Healthcare Market Research",
      message: "",
    },
  });

  function onSubmit(data: InsertContactSubmission) {
    submitContact.mutate(data, {
      onSuccess: () => {
        form.reset();
      }
    });
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow pt-24">
        {/* Header */}
        <section className="py-20 bg-white border-b border-gray-200" data-testid="section-contact-header">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                Get in Touch
              </p>
              <h1 className="font-display text-4xl md:text-5xl font-semibold text-[#003366] mb-6" data-testid="text-contact-title">
                Contact Us
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed" data-testid="text-contact-description">
                Whether you have a request, a query, or want to work with us, we're here to help you navigate the market.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Content */}
        <section className="py-20 bg-gray-50" data-testid="section-contact-content">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-5 gap-16">
              
              {/* Contact Info */}
              <div className="lg:col-span-2">
                <h2 className="font-display text-2xl font-semibold text-[#003366] mb-8">
                  Our Offices
                </h2>

                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="bg-white border border-gray-200 p-3">
                      <MapPin className="h-5 w-5 text-[#003366]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#003366] mb-1">Locations</h3>
                      <p className="text-gray-600 text-sm">128 City Road, London, UK EC1V 2NX</p>
                      <p className="text-gray-600 text-sm mt-1">1309 Coffeen Avenue STE 1200, Wyoming 82801, USA</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white border border-gray-200 p-3">
                      <Clock className="h-5 w-5 text-[#003366]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#003366] mb-1">Business Hours</h3>
                      <p className="text-gray-600 text-sm">Monday - Friday: 9:00 - 18:00</p>
                      <p className="text-gray-600 text-sm">Saturday - Sunday: Closed</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white border border-gray-200 p-3">
                      <Phone className="h-5 w-5 text-[#003366]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#003366] mb-1">Phone</h3>
                      <p className="text-gray-600 text-sm">+44 7727 666682</p>
                      <p className="text-gray-600 text-sm">+1 888 465 5557</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white border border-gray-200 p-3">
                      <Mail className="h-5 w-5 text-[#003366]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#003366] mb-1">Email</h3>
                      <p className="text-gray-600 text-sm">admin@bionixus.com</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form */}
              <div className="lg:col-span-3">
                <div className="bg-white border border-gray-200 p-8 md:p-10">
                  <h2 className="font-display text-2xl font-semibold text-[#003366] mb-8">
                    Send us a message
                  </h2>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[#003366]">First Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="John" 
                                  {...field} 
                                  className="border-gray-300 focus:border-[#0066CC] focus:ring-[#0066CC]"
                                  data-testid="input-firstname"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[#003366]">Last Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Doe" 
                                  {...field} 
                                  className="border-gray-300 focus:border-[#0066CC] focus:ring-[#0066CC]"
                                  data-testid="input-lastname"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[#003366]">Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="john@example.com" 
                                {...field} 
                                className="border-gray-300 focus:border-[#0066CC] focus:ring-[#0066CC]"
                                data-testid="input-email"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[#003366]">Phone (Optional)</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="+1 234 567 890" 
                                {...field} 
                                value={field.value || ''} 
                                className="border-gray-300 focus:border-[#0066CC] focus:ring-[#0066CC]"
                                data-testid="input-phone"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="preferredContact"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[#003366]">Preferred Contact</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value || "Email"}>
                                <FormControl>
                                  <SelectTrigger 
                                    className="border-gray-300"
                                    data-testid="select-preferred-contact"
                                  >
                                    <SelectValue placeholder="Select method" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Email">Email</SelectItem>
                                  <SelectItem value="Phone">Phone</SelectItem>
                                  <SelectItem value="Text">Text Message</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="serviceNeeded"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[#003366]">Service Needed</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value || "Healthcare Market Research"}>
                                <FormControl>
                                  <SelectTrigger 
                                    className="border-gray-300"
                                    data-testid="select-service"
                                  >
                                    <SelectValue placeholder="Select service" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Healthcare Market Research">Healthcare Market Research</SelectItem>
                                  <SelectItem value="Consumer Market Research">Consumer Market Research</SelectItem>
                                  <SelectItem value="Digital Transformation">Digital Transformation</SelectItem>
                                  <SelectItem value="Customer Experience">Customer Experience</SelectItem>
                                  <SelectItem value="Qualitative Research">Qualitative Research</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[#003366]">Message</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="How can we help you?" 
                                className="resize-none min-h-[140px] border-gray-300 focus:border-[#0066CC] focus:ring-[#0066CC]" 
                                {...field}
                                data-testid="textarea-message"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full bg-[#003366] hover:bg-[#002244] text-white py-6 font-medium"
                        disabled={submitContact.isPending}
                        data-testid="button-submit"
                      >
                        {submitContact.isPending ? "Sending..." : "Submit Request"}
                      </Button>
                    </form>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
