import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import type { BlogPost } from "@shared/schema";
import { ArrowRight, Calendar, Clock, User, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

function formatDate(date: Date | string | null) {
  if (!date) return "";
  const d = new Date(date);
  return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

function FeaturedArticle({ post }: { post: BlogPost }) {
  return (
    <Link href={`/insights/${post.slug}`} className="group block" data-testid={`featured-article-${post.slug}`}>
      <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
        <div className="relative overflow-hidden">
          <img 
            src={post.imageUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop"} 
            alt={post.title}
            className="w-full h-[350px] lg:h-[450px] object-cover grayscale contrast-110 group-hover:grayscale-0 transition-all duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/20 to-transparent" />
          <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
        </div>
        <div>
          <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
            <span className="text-[#0066CC] font-medium uppercase tracking-wider text-xs">{post.category}</span>
            <span className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              {formatDate(post.publishedAt)}
            </span>
          </div>
          <h2 className="font-display text-3xl lg:text-4xl font-semibold text-[#003366] mb-4 leading-tight group-hover:text-[#0066CC] transition-colors">
            {post.title}
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed mb-6">
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                <User className="h-5 w-5 text-gray-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#003366]">{post.author}</p>
                <p className="text-xs text-gray-500">{post.authorRole}</p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-sm text-gray-500">
              <Clock className="h-3.5 w-3.5" />
              {post.readTime}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

function ArticleCard({ post }: { post: BlogPost }) {
  return (
    <Link href={`/insights/${post.slug}`} className="group block" data-testid={`article-card-${post.slug}`}>
      <div className="bg-white border border-gray-200 h-full transition-all duration-300 hover:border-[#0066CC] hover:shadow-md">
        <div className="relative overflow-hidden">
          <img 
            src={post.imageUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop"} 
            alt={post.title}
            className="w-full h-[220px] object-cover grayscale contrast-110 group-hover:grayscale-0 transition-all duration-500"
          />
          <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
        </div>
        <div className="p-6">
          <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
            <span className="text-[#0066CC] font-medium uppercase tracking-wider">{post.category}</span>
            <span>{formatDate(post.publishedAt)}</span>
          </div>
          <h3 className="font-display text-xl font-semibold text-[#003366] mb-3 leading-snug group-hover:text-[#0066CC] transition-colors line-clamp-2">
            {post.title}
          </h3>
          <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between pt-4 border-t border-gray-100">
            <p className="text-sm font-medium text-[#003366]">{post.author}</p>
            <span className="text-xs text-gray-500">{post.readTime}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}

function ArticleCardSkeleton() {
  return (
    <div className="bg-white border border-gray-200">
      <Skeleton className="h-[220px] w-full" />
      <div className="p-6">
        <Skeleton className="h-4 w-24 mb-3" />
        <Skeleton className="h-6 w-full mb-2" />
        <Skeleton className="h-6 w-3/4 mb-3" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-2/3 mb-4" />
        <div className="flex justify-between pt-4 border-t border-gray-100">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-16" />
        </div>
      </div>
    </div>
  );
}

export default function Blog() {
  const { data: posts, isLoading } = useQuery<BlogPost[]>({
    queryKey: [api.blog.list.path],
  });

  const featuredPosts = posts?.filter(p => p.featured) || [];
  const regularPosts = posts?.filter(p => !p.featured) || [];
  const categories = [...new Set(posts?.map(p => p.category) || [])];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Header */}
        <section className="py-20 bg-white border-b border-gray-200" data-testid="section-blog-header">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
              <div className="max-w-3xl">
                <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                  Insights & Research
                </p>
                <h1 className="font-display text-4xl md:text-5xl font-semibold text-[#003366] mb-6" data-testid="text-blog-title">
                  Insights
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed" data-testid="text-blog-description">
                  Expert perspectives on healthcare markets, pharmaceutical research, and the latest trends shaping the industry.
                </p>
              </div>
              <div className="flex-shrink-0 flex flex-col sm:flex-row gap-2">
                <a href="/api/export/wordpress-theme" download>
                  <Button variant="default" className="gap-2 bg-[#003366] hover:bg-[#002244]" data-testid="button-download-theme">
                    <Download className="h-4 w-4" />
                    Download WP Theme
                  </Button>
                </a>
                <a href="/api/blog/export/wordpress" download>
                  <Button variant="outline" className="gap-2" data-testid="button-export-wordpress">
                    <Download className="h-4 w-4" />
                    Export Blog Posts
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Article */}
        {!isLoading && featuredPosts.length > 0 && (
          <section className="py-16 bg-gray-50" data-testid="section-featured">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-8">
                Featured
              </p>
              <FeaturedArticle post={featuredPosts[0]} />
            </div>
          </section>
        )}

        {/* Categories Bar */}
        {categories.length > 0 && (
          <section className="py-8 bg-white border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <div className="flex flex-wrap gap-4">
                <span className="text-sm font-medium text-[#003366] border-b-2 border-[#0066CC] pb-1">
                  All Articles
                </span>
                {categories.map((cat) => (
                  <span 
                    key={cat} 
                    className="text-sm text-gray-500 hover:text-[#003366] cursor-pointer pb-1"
                  >
                    {cat}
                  </span>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Articles Grid */}
        <section className="py-16 bg-white" data-testid="section-articles">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {isLoading ? (
                <>
                  <ArticleCardSkeleton />
                  <ArticleCardSkeleton />
                  <ArticleCardSkeleton />
                </>
              ) : (
                <>
                  {featuredPosts.slice(1).map((post) => (
                    <ArticleCard key={post.id} post={post} />
                  ))}
                  {regularPosts.map((post) => (
                    <ArticleCard key={post.id} post={post} />
                  ))}
                </>
              )}
            </div>
          </div>
        </section>

        {/* Newsletter CTA */}
        <section className="py-20 bg-[#003366]" data-testid="section-newsletter">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="font-display text-3xl font-semibold text-white mb-4">
              Stay informed
            </h2>
            <p className="text-lg text-blue-200 mb-8 max-w-2xl mx-auto">
              Subscribe to receive our latest insights, research reports, and industry analysis directly in your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 text-sm border-0 focus:ring-2 focus:ring-white"
                data-testid="input-newsletter-email"
              />
              <button 
                className="bg-white text-[#003366] px-6 py-3 font-medium hover:bg-gray-100 transition-colors flex items-center justify-center gap-2"
                data-testid="button-newsletter-subscribe"
              >
                Subscribe
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
