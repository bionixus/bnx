import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ServiceCard } from "@/components/ServiceCard";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  BarChart3, 
  Globe2, 
  Users, 
  LineChart, 
  Bot, 
  TrendingUp,
  ArrowRight,
  CheckCircle2
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        {/* HERO SECTION - McKinsey Style */}
        <section className="relative pt-32 pb-24 lg:pt-40 lg:pb-32 bg-white overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-gray-50 to-transparent" />
          
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4" data-testid="text-hero-tag">
                  Market Research & Consulting
                </p>
                
                <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-semibold text-[#003366] leading-tight mb-6" data-testid="text-hero-title">
                  Precision insights for global healthcare
                </h1>

                <p className="text-lg text-gray-600 mb-10 leading-relaxed max-w-xl" data-testid="text-hero-description">
                  We combine traditional research rigor with advanced methodologies to deliver actionable intelligence for pharmaceutical and healthcare organizations across the Middle East and Africa.
                </p>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/services">
                    <Button 
                      size="lg" 
                      className="bg-[#003366] hover:bg-[#002244] text-white px-8 py-6 text-base font-medium"
                      data-testid="button-hero-services"
                    >
                      Explore Our Services
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                  <Link href="/contact">
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="border-[#003366] text-[#003366] hover:bg-gray-50 px-8 py-6 text-base font-medium"
                      data-testid="button-hero-contact"
                    >
                      Contact an Expert
                    </Button>
                  </Link>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="relative hidden lg:block"
              >
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?q=80&w=1000&auto=format&fit=crop" 
                    alt="Healthcare Analytics"
                    className="w-full h-[500px] object-cover grayscale contrast-110"
                    data-testid="img-hero"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/10 to-transparent" />
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* STATS SECTION */}
        <section className="py-16 bg-[#003366]" data-testid="section-stats">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { value: "60%", label: "Sales Increase", sublabel: "Up to" },
                { value: "12+", label: "Countries", sublabel: "MEA Region" },
                { value: "1M+", label: "Data Points", sublabel: "Analyzed" },
                { value: "100%", label: "Retention", sublabel: "Client" },
              ].map((stat, i) => (
                <div key={i} className="text-center" data-testid={`stat-${i}`}>
                  <div className="text-4xl md:text-5xl font-display font-semibold text-white mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm font-medium text-white uppercase tracking-wider">
                    {stat.label}
                  </div>
                  <div className="text-xs text-blue-300 mt-1">
                    {stat.sublabel}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SERVICES SECTION */}
        <section className="py-24 bg-gray-50" data-testid="section-services">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-3xl mb-16">
              <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                What We Do
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-[#003366] mb-6">
                Comprehensive market intelligence
              </h2>
              <p className="text-lg text-gray-600">
                From quantitative data to qualitative insights, we provide end-to-end solutions for the pharmaceutical industry.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <ServiceCard 
                icon={BarChart3}
                title="Quantitative Research"
                description="Specialized pharmaceutical market research across therapy areas including Oncology, Biologics, and Diabetes."
              />
              <ServiceCard 
                icon={Users}
                title="Qualitative Research"
                description="In-depth interviews, focus groups, and ethnographic studies to uncover patient and HCP perspectives."
              />
              <ServiceCard 
                icon={LineChart}
                title="Market Analytics"
                description="Consumer behavior analysis, market trend monitoring, and competitive landscape assessment."
              />
              <ServiceCard 
                icon={Globe2}
                title="Regional Expertise"
                description="Deep understanding of Middle East cultural nuances and regulatory landscapes."
              />
            </div>
          </div>
        </section>

        {/* FEATURED INSIGHT */}
        <section className="py-24 bg-white" data-testid="section-insight">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=1000&auto=format&fit=crop" 
                  alt="Team Meeting"
                  className="w-full h-[450px] object-cover grayscale contrast-110"
                  data-testid="img-insight"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-[#003366]/10 to-transparent" />
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#0066CC]" />
              </div>

              <div>
                <p className="text-[#0066CC] font-medium text-sm uppercase tracking-wider mb-4">
                  Our Approach
                </p>
                <h2 className="font-display text-3xl md:text-4xl font-semibold text-[#003366] mb-6">
                  Driven by values, powered by data
                </h2>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  We position ourselves as the partner for pharmaceutical companies seeking to navigate complex Middle East healthcare markets successfully.
                </p>

                <div className="space-y-5">
                  {[
                    "Global experience with multinational companies across continents",
                    "Uncompromising quality standards delivering precise insights",
                    "Tailored solutions customized to your exact needs",
                    "Rigorous ethical standards and compliance protocols"
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-[#0066CC] mt-0.5 shrink-0" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-10">
                  <Link href="/about">
                    <Button 
                      variant="outline" 
                      className="border-[#003366] text-[#003366] hover:bg-gray-50 font-medium"
                      data-testid="button-insight-about"
                    >
                      Learn About Us
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="py-20 bg-gray-50 border-t border-gray-200" data-testid="section-cta">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-[#003366] mb-6">
              Ready to make your next move?
            </h2>
            <p className="text-lg text-gray-600 mb-10 max-w-2xl mx-auto">
              Get the insights you need to make data-driven decisions. Contact our team of experts today.
            </p>
            <Link href="/contact">
              <Button 
                size="lg" 
                className="bg-[#003366] hover:bg-[#002244] text-white px-10 py-6 text-base font-medium"
                data-testid="button-cta-contact"
              >
                Get in Touch
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
