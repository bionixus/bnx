import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import archiver from "archiver";
import path from "path";
import fs from "fs";

async function seedBlogPosts() {
  const existingPosts = await storage.getBlogPosts();
  if (existingPosts.length === 0) {
    const posts = [
      {
        slug: "uae-influenza-vaccine-report",
        title: "What 6,000+ Shots Reveal: UAE Influenza Vaccine Report",
        excerpt: "Overview of the BioNixus UAE influenza vaccine report focusing on Vaxigrip, Influvac, Fluzone and the launch readiness analysis for Flumist, the latest Influenza vaccine inhaler.",
        content: `<h2>What 6,000+ Flu Shots Reveal: 4 Surprising Trends from Dubai's Top Hospitals</h2>

<h3>Beyond the Annual Jab</h3>
<p>For many families, the annual flu shot is a routine part of the healthcare calendar—a quick visit, a minor pinch, and a sense of preparedness for the season. But behind this simple act lies a complex story of public health strategy and patient behavior. An analysis of influenza vaccination data from over 6,000 patients across major Dubai hospitals in 2024 uncovers surprising patterns. More profoundly, the data reveals a tale of two healthcare systems—a highly standardized public sector and a more diverse private one—operating in parallel to keep the city healthy.</p>

<h3>1. The Great Divide: Some Hospitals Vaccinate Only Kids, Others Only Adults</h3>
<p>The first key insight is a stark specialization in patient demographics, a trend that appears to be a hallmark of the public healthcare strategy. While one might expect large hospitals to serve all age groups, the data reveals a highly structured approach where certain public facilities are designated as hubs for either pediatric or adult preventative care.</p>
<p>The numbers are absolute. At Al Jalila Hospital (a dedicated public children's hospital), 100% of the 1,018 patients vaccinated were pediatrics (17 years old or younger). In sharp contrast, at two other major public facilities, Dubai Hospital and Rashid Hospital, 100% of their vaccinated patients (1,038 and 1,296, respectively) were adults.</p>

<h3>2. A Laser Focus on At-Risk Children</h3>
<p>The data also highlights a remarkably successful public health effort to protect the most vulnerable pediatric populations. Across both public and private hospitals, a significant majority of vaccinated children between the ages of 2 and 17 were those with asthma, a condition that can lead to serious complications from the flu.</p>
<p>At Mediclinic City Hospital, 68% of vaccinated children (2-17 years old) were asthmatic. At Mediclinic Parkview Hospital, the figure was 63%. At Kings College Hospital, 58% of this group were asthmatic patients.</p>

<h3>3. The Unexpected Brand Battlefield: Vaxigrip vs. Influvac</h3>
<p>A look at the specific vaccines administered reveals that there isn't one dominant product across the city. Instead, this brand bifurcation is a clear indicator of differing procurement and supply chain strategies between the public and private healthcare sectors.</p>
<p><strong>Vaxigrip Dominance in the Public Sector.</strong> The three public hospitals in this analysis—Al Jalila, Dubai, and Rashid—exclusively used Vaxigrip for all their influenza vaccinations.</p>
<p><strong>A Mixed Market in the Private Sector.</strong> Conversely, the private sector shows varied preferences. The Mediclinic group heavily favors Influvac.</p>

<h3>4. The Out-of-Pocket Surprise: Many Families Pay Directly for Vaccination</h3>
<p>The final insight is a financial one, reflecting systemic differences in insurance and payment models. While public hospitals offer comprehensive coverage for this preventative measure, a significant number of patients in the private sector pay for flu shots out-of-pocket.</p>
<p>At the public Dubai Hospital and Rashid Hospital, 100% of adult vaccinations in the 18-49 age group were covered by health insurance. At Mediclinic Parkview Hospital, 44% of adults in the same age group paid out-of-pocket.</p>

<h3>A Deeper Look at Public Health</h3>
<p>The data from over 6,000 vaccinations reveals that Dubai's annual flu shot campaign is not a one-size-fits-all process. It is a sophisticated, multi-pronged approach where the public and private sectors play distinct yet complementary roles.</p>`,
        author: "BioNixus",
        authorRole: "Research Team",
        category: "Market Research",
        imageUrl: "https://images.unsplash.com/photo-1618044733300-9472054094ee?q=80&w=1000&auto=format&fit=crop",
        readTime: "3 min read",
        featured: true,
        publishedAt: new Date("2025-11-30"),
      },
      {
        slug: "skyrizi-tops-julys-pharma-rankings",
        title: "Skyrizi Tops July's Pharma Rankings — and What It Means for Omnichannel Engagement",
        excerpt: "In July 2025, pharma campaigns didn't just grab attention — they sparked full-funnel engagement. AbbVie's Skyrizi took the No. 1 spot with a 22% SOV surge.",
        content: `<h2>Pharma Digital Leaders in July: Skyrizi Secures Top Spot in USA</h2>
<p>In July 2025, pharma brands poured millions into TV ads — but the most successful campaigns didn't stop there. The top performers used TV as the spark in a wider omnichannel fire, driving engagement across digital, HCP portals, and patient communities.</p>
<p>AbbVie's <strong>Skyrizi</strong> emerged as the top pharmaceutical brand on U.S. television in July, dethroning June's leader, Tremfya, and demonstrating the power of strategic ad spend during high-engagement programming.</p>
<p>The psoriasis treatment recorded <strong>2.5 billion TV impressions</strong>, capturing a <strong>4.61% share of voice (SOV)</strong>. This marked a <strong>22% jump in SOV from June to July</strong>, fueled by a <strong>14.5% increase in ad spend</strong> to <strong>$34.7 million</strong>.</p>

<h3>Notable Brand Movements</h3>
<ul>
<li><strong>Tremfya</strong> slipped to No. 2 with $21.6M in TV spend, securing 2.1B impressions.</li>
<li><strong>Rinvoq</strong> jumped from fifth to third place despite reducing spend from $28M in June to $25.5M in July — a signal of improved efficiency in media buys.</li>
<li><strong>Advil</strong> dropped from third to fourth, reducing spend by nearly $3M to $5.1M.</li>
<li><strong>Dupixent</strong> re-entered the top five with 1.6B impressions at a steady $13.6M spend.</li>
</ul>

<h3>Networks and Programming Driving Results</h3>
<p>The top TV networks for pharma advertisers in July were ABC, CBS, and NBC, with ABC World News Tonight With David Muir remaining the single most impactful program for reach.</p>
<p>Interestingly, news programming proved to be a significant driver of impressions: CNN pharma ad impressions rose 76% year-over-year in July. NewsNation was up 52%. MSNBC increased 36%.</p>

<h3>From TV to Omnichannel: Turning Reach into Measurable Impact</h3>
<p>While July's numbers show where pharma brands spent their TV budgets, the real competitive edge comes from how those impressions are activated across the full customer journey.</p>
<ol>
<li><strong>TV as the Awareness Catalyst</strong> - National TV, especially news programming, delivers unmatched reach and trust.</li>
<li><strong>Digital Retargeting to Sustain Recall</strong> - Programmatic platforms, social ads, and YouTube pre-roll are used to re-engage audiences.</li>
<li><strong>CRM and HCP Portals to Drive Action</strong> - TV prompts interest, but email marketing and gated HCP portals convert curiosity into engagement.</li>
<li><strong>Patient Support Programs to Build Loyalty</strong> - Follow-up via SMS, app notifications, and patient education videos reinforces adherence.</li>
</ol>

<h3>BioNixus Insight</h3>
<p>At BioNixus, we track these brand trends in real time to help pharma and healthcare companies make smarter marketing and media investments, optimize channel mix, and benchmark against competitors.</p>`,
        author: "BioNixus",
        authorRole: "Research Team",
        category: "Market Research",
        imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000&auto=format&fit=crop",
        readTime: "3 min read",
        featured: true,
        publishedAt: new Date("2025-08-08"),
      },
      {
        slug: "techniques-and-tools-in-quantitative-healthcare-market-research",
        title: "Techniques and Tools in Quantitative Healthcare Market Research",
        excerpt: "Types of quantitative market research and different tools in data design, collection and analysis for the pharmaceutical and healthcare sectors.",
        content: `<h2>Techniques and Tools in Quantitative Healthcare Market Research</h2>
<p>Quantitative healthcare market research employs a variety of techniques and tools that are integral to gathering and analyzing data to formulate strategic insights. One foundational aspect is the design of surveys and questionnaires, which are often structured to yield numerical data that can be statistically analyzed.</p>
<p>The questions in these instruments must be carefully crafted to ensure clarity and relevance, facilitating precise responses from participants. Various types of questions, including multiple choice, rating scales, and dichotomous questions, are typically used to capture a wide range of data necessary for comprehensive analysis.</p>

<h3>Distribution Methods</h3>
<p>To maximize reach and enhance the validity of the data collected, diverse distribution methods are utilized. These methods may include HCP interviews, country-based data, Chain or sector-based data, Area and brick-level Data, hospital-level Data or even online surveys facilitated through platforms such as SurveyMonkey or Qualtrics, telephone interviews, or even face-to-face interactions, depending on the target demographic.</p>

<h3>Data Analysis</h3>
<p>Once data is collected, the next crucial phase involves analyzing the responses to glean actionable insights. The application of statistical and analytical software, such as SPSS, SAS, or R, plays a vital role in this phase. These tools enable researchers to conduct complex analyses, including regression analysis, variance analysis, and factor analysis, increasing the accuracy and relevance of findings.</p>

<h3>Challenges and Future Trends</h3>
<p>Quantitative market research in the pharmaceutical industry faces several notable challenges. One of the most pressing issues is data privacy concerns. With the increasing focus on protecting personal health information, researchers must navigate stringent regulations such as HIPAA and GDPR.</p>
<p>However, the future of quantitative market research also presents promising trends. The integration of artificial intelligence (AI) and machine learning is reshaping how data is processed and interpreted. Furthermore, big data analytics is revolutionizing research by enabling the analysis of vast amounts of information in real time.</p>`,
        author: "Mela Belba",
        authorRole: "Research Analyst",
        category: "Research",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop",
        readTime: "2 min read",
        featured: false,
        publishedAt: new Date("2025-05-31"),
      },
      {
        slug: "quantitative-healthcare-market-research",
        title: "The Crucial Role of Quantitative Market Research in the Pharma Industry",
        excerpt: "The importance of Quantitative market research in the pharma and healthcare industries for informed decision-making and successful marketing strategies.",
        content: `<h2>The Importance of Market Research in the Pharma Industry</h2>
<p>Market research in the pharma is an indispensable tool that empowers companies to navigate complexities inherent to the healthcare landscape. This research provides critical insights into trends, consumer behavior, and competitive dynamics, enabling pharmaceutical organizations to make informed decisions for drug launch and marketing.</p>

<h3>Why Market Research Matters</h3>
<p>One of the main benefits of conducting thorough market research is its capacity to uncover unmet medical and marketing needs. By systematically evaluating healthcare outcomes, patient feedback, and treatment gaps, pharmaceutical companies can provide innovative solutions that address significant health challenges.</p>
<p>Moreover, market research aids in assessing the market potential for new therapies. This evaluation encompasses a variety of factors including target demographics, pricing strategies, and potential barriers to entry. A well-targeted market analysis enables firms to estimate the size of their intended market, project sales volumes, and determine appropriate marketing approaches.</p>

<h3>The Consequences of Inadequate Research</h3>
<p>Conversely, inadequate market research can lead to critical consequences, jeopardizing the success of pharmaceutical initiatives. Failing to thoroughly understand market dynamics may result in misguided product launches, wherein companies introduce drugs that fail to meet the actual needs of patients or healthcare providers.</p>

<h3>Quantitative Market Research and Its Role</h3>
<p>Quantitative market research serves as a vital instrument within the pharmaceutical industry, enabling marketers to gain critical insights into market dynamics and consumer behavior. Through the systematic collection and statistical analysis of numerical data, quantitative methodologies facilitate a deeper understanding of various market trends.</p>
<p>The significance of quantitative research lies in its ability to objectively evaluate the success of existing products while forecasting potential outcomes for new drug launches. By analyzing sales data and customer feedback quantitatively, pharmaceutical firms can assess whether a product meets market needs and expectations.</p>`,
        author: "BioNixus Teams",
        authorRole: "Research Team",
        category: "Market Research",
        imageUrl: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?q=80&w=1000&auto=format&fit=crop",
        readTime: "2 min read",
        featured: false,
        publishedAt: new Date("2025-05-30"),
      },
      {
        slug: "chatgpt-is-down",
        title: "ChatGPT is Down Today Due to Server Error: Top 5 Alternatives to Consider",
        excerpt: "ChatGPT is down, Here's the top 5 alternatives to ChatGPT including Gemini, Microsoft Copilot, Grok AI, Claude, and Meta LLAMA AI.",
        content: `<p>In the world of artificial intelligence, tools like ChatGPT have revolutionized how we interact with machines and access information. However, even the most reliable services can experience downtime. If you find yourself unable to access ChatGPT today due to server error, fear not! This article explores the top five alternatives that can provide similar functionality.</p>

<h2>1. Gemini</h2>
<p>Previously known as "Google Bard" is a powerful conversational AI tool developed by Google that offers impressive capabilities. Designed to assist with generating content, answering queries, and even engaging in casual conversation, Gemini utilizes Google's vast database. Its ease of use and integration with other Google services make it a strong contender.</p>

<h2>2. Microsoft Copilot</h2>
<p>Another excellent alternative is Microsoft Bing or Copilot Chat. Integrated with the Bing search engine, this tool has advanced chat functionalities that allow you to ask questions and receive immediate, contextually relevant answers.</p>

<h2>3. Grok AI</h2>
<p>Grok is a generative artificial intelligence chatbot developed by xAI. Based on the large language model (LLM) of the same name, it was launched in 2023 as an initiative by Elon Musk. The chatbot is advertised as having a "sense of humor" and direct access to X (formerly Twitter).</p>

<h2>4. Claude</h2>
<p>Claude is a next generation AI assistant built by Anthropic and trained to be safe, accurate, and secure to help you do your best work. Claude is an excellent choice to explore during ChatGPT's server downtime.</p>

<h2>5. Meta LLAMA AI</h2>
<p>LLaMA 3, which stands for Large Language Model Meta AI 3, is the latest open-source large language model development service created by Meta. It's been trained on a huge amount of text data, which helps it understand language really well.</p>

<h3>Advice for the future</h3>
<p>While facing server errors with ChatGPT can be frustrating, knowing alternative AI solutions can help mitigate the impact on your workflow. These tools can provide functionalities that may meet your needs effectively.</p>`,
        author: "Mohammad Alsaadany",
        authorRole: "Technology Writer",
        category: "Technology",
        imageUrl: "https://images.unsplash.com/photo-1710993011836-108ba89ebe51?q=80&w=1000&auto=format&fit=crop",
        readTime: "2 min read",
        featured: false,
        publishedAt: new Date("2024-12-26"),
      },
      {
        slug: "market-research-methods-simplified",
        title: "Market Research Methods Simplified: How to Understand Your Customers Like Marvel",
        excerpt: "Dive deep into the world of market research and uncover the secrets to understanding your customers like never before with these essential methods.",
        content: `<p>Are you ready to dive deep into the world of market research and uncover the secrets to understanding your customers like never before? In this article, we're going to explore some killer market research methods that will have you crushing it in no time.</p>

<h2>The Power of Market Research</h2>
<p>First things first, let's talk about what market research actually is. Market research is the process of gathering, analyzing, and interpreting information about a market, product, or service. This invaluable data allows businesses to better understand their customers, competitors, and industry trends.</p>

<h3>Why Market Research Matters</h3>
<p>Without understanding your target audience and their needs, wants, and preferences, you're basically shooting in the dark. Market research helps you hit that target dead center by providing you with the insights you need to tailor your messaging, products, and services to meet your customers' expectations.</p>

<h2>Market Research Methods 101</h2>

<h3>Surveys: Your Secret Weapon</h3>
<p>Surveys are a tried and true market research method that allows you to gather feedback directly from your customers. Whether you conduct online surveys, phone surveys, or in-person surveys, asking the right questions can provide you with valuable insights into your customers' preferences, satisfaction levels, and purchasing behaviors.</p>

<h3>Focus Groups: The Avengers of Market Research</h3>
<p>Focus groups bring together a small group of customers to discuss a specific topic or product. By facilitating a structured conversation, you can gain deeper insights into your customers' perceptions, attitudes, and motivations.</p>

<h3>Social Media Monitoring</h3>
<p>In today's digital age, social media is a goldmine of customer data waiting to be discovered. By monitoring social media platforms like Facebook, Twitter, and Instagram, you can track conversations, trends, and sentiments related to your brand or industry.</p>

<h3>Competitor Analysis: The Art of War</h3>
<p>Competitor analysis is a crucial market research method that can give you a competitive edge. By studying your competitors' strengths, weaknesses, and strategies, you can identify gaps in the market, spot emerging trends, and differentiate your brand.</p>

<h2>Go Forth and Conquer</h2>
<p>Armed with these market research methods, you now have the tools and techniques to kick butt in understanding your customers and dominating your competition. Remember, the key to success is not just collecting data, but interpreting it and using it to make informed decisions.</p>`,
        author: "Mark Manson",
        authorRole: "Marketing Strategist",
        category: "Research",
        imageUrl: "https://images.unsplash.com/photo-1543286386-2e659306cd6c?q=80&w=1000&auto=format&fit=crop",
        readTime: "3 min read",
        featured: false,
        publishedAt: new Date("2024-08-16"),
      },
    ];

    for (const post of posts) {
      await storage.createBlogPost(post);
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed blog posts on startup
  await seedBlogPosts();

  // Contact form submission
  app.post(api.contact.submit.path, async (req, res) => {
    try {
      const input = api.contact.submit.input.parse(req.body);
      const submission = await storage.createContactSubmission(input);
      res.status(201).json(submission);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Blog posts list
  app.get(api.blog.list.path, async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const featured = req.query.featured === 'true' ? true : undefined;
      const posts = await storage.getBlogPosts(category, featured);
      res.json(posts);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Single blog post
  app.get(api.blog.get.path, async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json(post);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // WordPress export endpoint - generates WXR format XML
  app.get('/api/blog/export/wordpress', async (req, res) => {
    try {
      const posts = await storage.getBlogPosts();
      
      const escapeXml = (text: string) => {
        return text
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&apos;');
      };

      const formatDate = (date: Date) => {
        return date.toISOString().slice(0, 19).replace('T', ' ');
      };

      const formatPubDate = (date: Date) => {
        return date.toUTCString();
      };

      let xml = `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0"
  xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:wfw="http://wellformedweb.org/CommentAPI/"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:wp="http://wordpress.org/export/1.2/"
>
<channel>
  <title>BioNixus Market Research</title>
  <link>https://www.bionixus.com</link>
  <description>Healthcare and Pharmaceutical Market Research Insights</description>
  <pubDate>${formatPubDate(new Date())}</pubDate>
  <language>en-US</language>
  <wp:wxr_version>1.2</wp:wxr_version>
  <wp:base_site_url>https://www.bionixus.com</wp:base_site_url>
  <wp:base_blog_url>https://www.bionixus.com</wp:base_blog_url>
`;

      // Add categories
      const categories = [...new Set(posts.map(p => p.category))];
      categories.forEach((cat, index) => {
        xml += `
  <wp:category>
    <wp:term_id>${index + 1}</wp:term_id>
    <wp:category_nicename><![CDATA[${cat.toLowerCase().replace(/\s+/g, '-')}]]></wp:category_nicename>
    <wp:category_parent></wp:category_parent>
    <wp:cat_name><![CDATA[${cat}]]></wp:cat_name>
  </wp:category>`;
      });

      // Add posts
      posts.forEach((post, index) => {
        const pubDate = post.publishedAt ? new Date(post.publishedAt) : new Date();
        xml += `
  <item>
    <title>${escapeXml(post.title)}</title>
    <link>https://www.bionixus.com/insights/${post.slug}</link>
    <pubDate>${formatPubDate(pubDate)}</pubDate>
    <dc:creator><![CDATA[${post.author}]]></dc:creator>
    <guid isPermaLink="false">https://www.bionixus.com/?p=${post.id}</guid>
    <description></description>
    <content:encoded><![CDATA[${post.content}]]></content:encoded>
    <excerpt:encoded><![CDATA[${post.excerpt}]]></excerpt:encoded>
    <wp:post_id>${post.id}</wp:post_id>
    <wp:post_date><![CDATA[${formatDate(pubDate)}]]></wp:post_date>
    <wp:post_date_gmt><![CDATA[${formatDate(pubDate)}]]></wp:post_date_gmt>
    <wp:post_modified><![CDATA[${formatDate(pubDate)}]]></wp:post_modified>
    <wp:post_modified_gmt><![CDATA[${formatDate(pubDate)}]]></wp:post_modified_gmt>
    <wp:comment_status><![CDATA[open]]></wp:comment_status>
    <wp:ping_status><![CDATA[open]]></wp:ping_status>
    <wp:post_name><![CDATA[${post.slug}]]></wp:post_name>
    <wp:status><![CDATA[publish]]></wp:status>
    <wp:post_parent>0</wp:post_parent>
    <wp:menu_order>0</wp:menu_order>
    <wp:post_type><![CDATA[post]]></wp:post_type>
    <wp:post_password><![CDATA[]]></wp:post_password>
    <wp:is_sticky>0</wp:is_sticky>
    <category domain="category" nicename="${post.category.toLowerCase().replace(/\s+/g, '-')}"><![CDATA[${post.category}]]></category>
    <wp:postmeta>
      <wp:meta_key><![CDATA[_thumbnail_url]]></wp:meta_key>
      <wp:meta_value><![CDATA[${post.imageUrl}]]></wp:meta_value>
    </wp:postmeta>
    <wp:postmeta>
      <wp:meta_key><![CDATA[author_role]]></wp:meta_key>
      <wp:meta_value><![CDATA[${post.authorRole}]]></wp:meta_value>
    </wp:postmeta>
    <wp:postmeta>
      <wp:meta_key><![CDATA[read_time]]></wp:meta_key>
      <wp:meta_value><![CDATA[${post.readTime}]]></wp:meta_value>
    </wp:postmeta>
    <wp:postmeta>
      <wp:meta_key><![CDATA[featured]]></wp:meta_key>
      <wp:meta_value><![CDATA[${post.featured ? '1' : '0'}]]></wp:meta_value>
    </wp:postmeta>
  </item>`;
      });

      xml += `
</channel>
</rss>`;

      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', 'attachment; filename="bionixus-blog-wordpress-export.xml"');
      res.send(xml);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // WordPress theme download endpoint
  app.get('/api/export/wordpress-theme', async (req, res) => {
    try {
      const themePath = path.join(process.cwd(), 'wordpress-theme', 'bionixus-theme');
      
      if (!fs.existsSync(themePath)) {
        return res.status(404).json({ message: "WordPress theme not found" });
      }

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="bionixus-theme.zip"');

      const archive = archiver('zip', { zlib: { level: 9 } });
      
      archive.on('error', (err) => {
        throw err;
      });

      archive.pipe(res);
      archive.directory(themePath, 'bionixus-theme');
      await archive.finalize();
    } catch (err) {
      console.error('Error creating theme zip:', err);
      res.status(500).json({ message: "Error creating theme download" });
    }
  });

  return httpServer;
}
