import { 
  contactSubmissions, 
  blogPosts,
  type InsertContactSubmission, 
  type ContactSubmission,
  type InsertBlogPost,
  type BlogPost
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getBlogPosts(category?: string, featured?: boolean): Promise<BlogPost[]>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
}

export class DatabaseStorage implements IStorage {
  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const [result] = await db.insert(contactSubmissions).values(submission).returning();
    return result;
  }

  async getBlogPosts(category?: string, featured?: boolean): Promise<BlogPost[]> {
    let query = db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
    const results = await query;
    
    let filtered = results;
    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }
    if (featured !== undefined) {
      filtered = filtered.filter(p => p.featured === featured);
    }
    return filtered;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [result] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return result;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [result] = await db.insert(blogPosts).values(post).returning();
    return result;
  }
}

export const storage = new DatabaseStorage();
